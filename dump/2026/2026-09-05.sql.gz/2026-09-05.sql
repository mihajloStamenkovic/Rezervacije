--
-- PostgreSQL database dump
--

\restrict DW6rUsZGdCTTKA5YoQcubCwy4xUJyRgdVTitmA9RueLa440X8hvghQhHwfciyWw

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.11 (Ubuntu 17.11-1.pgdg24.04+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA "public";


--
-- Name: SCHEMA "public"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA "public" IS 'standard public schema';


--
-- Name: je_clan(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."je_clan"() RETURNS boolean
    LANGUAGE "sql" STABLE SECURITY DEFINER
    SET "search_path" TO 'public', 'pg_temp'
    AS $$
	SELECT EXISTS (
		SELECT 1 FROM "public"."profiles" WHERE "id" = (SELECT auth.uid())
	);
$$;


--
-- Name: FUNCTION "je_clan"(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION "public"."je_clan"() IS 'Da li prijavljeni nalog ima red u profiles. Jedina definicija pristupa aplikaciji.';


SET default_tablespace = '';

SET default_table_access_method = "heap";

--
-- Name: destinacije; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."destinacije" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "drzava" "text" NOT NULL,
    "drzava_sifra" "text" NOT NULL,
    "regija" "text" NOT NULL,
    "grad" "text" NOT NULL,
    "aktivna" boolean DEFAULT true NOT NULL,
    "redosled" integer DEFAULT 0 NOT NULL
);


--
-- Name: profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."profiles" (
    "id" "uuid" NOT NULL,
    "ime" "text" NOT NULL,
    "email" "text" NOT NULL,
    "boja" "text" NOT NULL
);


--
-- Name: reservations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."reservations" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "ime" "text" NOT NULL,
    "telefon" "text" NOT NULL,
    "destinacija_id" "uuid" NOT NULL,
    "datum_polaska" "date" NOT NULL,
    "destinacija_povratka_id" "uuid" NOT NULL,
    "datum_povratka" "date",
    "broj_putnika" integer NOT NULL,
    "kreirao" "uuid" NOT NULL,
    CONSTRAINT "reservations_broj_putnika_pozitivan" CHECK (("broj_putnika" > 0)),
    CONSTRAINT "reservations_povratak_posle_polaska" CHECK ((("datum_povratka" IS NULL) OR ("datum_povratka" >= "datum_polaska")))
);


--
-- Name: settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."settings" (
    "id" integer DEFAULT 1 NOT NULL,
    "podrazumevana_destinacija_id" "uuid" NOT NULL,
    CONSTRAINT "settings_jedan_red" CHECK (("id" = 1))
);


--
-- Data for Name: destinacije; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."destinacije" ("id", "drzava", "drzava_sifra", "regija", "grad", "aktivna", "redosled") FROM stdin;
de97c014-4065-4e50-9599-f198f979d2cb	Srbija	srbija	Beograd	Beograd	t	0
c99e0e87-e42d-4d2c-99fb-f010ba5f4bb9	Srbija	srbija	Kopaonik	Kopaonik	t	1
8d1e8dc7-720d-4dc0-b74f-fe4330f49f61	Grčka	grcka	Solun i okolina	Solun	t	0
9749d9b7-466c-4f44-a5ee-3b5fbb86d15f	Grčka	grcka	Solun i okolina	Perea	t	1
759f31dc-5772-4206-bcb6-92b55f56e031	Grčka	grcka	Solun i okolina	Nea Kalikratija	t	2
c1cd7cc7-f851-47ce-9ec0-1a138c2d8892	Grčka	grcka	Solun i okolina	Nea Mudanja	t	3
e78c7f33-0f6b-4359-b46e-f9c92c81dc3e	Grčka	grcka	Sitonija	Sarti	t	4
cab5f6e5-cf31-40db-a1b0-ed626c580bef	Grčka	grcka	Sitonija	Neos Marmaras	t	5
eac12b0e-b30d-4eec-9213-ac25fe5fe234	Grčka	grcka	Sitonija	Nikiti	t	6
c1f43945-052f-48a3-9852-399a07456f46	Grčka	grcka	Sitonija	Vurvuru	t	7
0f931bbb-4b8e-4923-8bc0-2b6bd76b30f9	Grčka	grcka	Sitonija	Toroni	t	8
231697c4-fc4f-40c9-8ba1-43f64dd65411	Grčka	grcka	Sitonija	Metamorfosis	t	9
d733552e-8f8f-462b-a326-adc6bbaf7fe8	Grčka	grcka	Kasandra	Hanioti	t	10
4630535d-6d15-4d6f-bf64-2bb873fb4f70	Grčka	grcka	Kasandra	Pefkohori	t	11
03ca584e-d562-4050-9e07-dc3bea87a1ba	Grčka	grcka	Kasandra	Polihrono	t	12
c07f8a3a-614c-43ef-941d-8871a08f4506	Grčka	grcka	Kasandra	Kalitea	t	13
2cd590ef-e475-4480-b924-157db50ca00a	Grčka	grcka	Kasandra	Afitos	t	14
a15be6b4-e91f-4661-b590-89dc5a370075	Grčka	grcka	Kasandra	Siviri	t	15
9fbde431-7bf1-4016-8a4e-2dd497b50766	Grčka	grcka	Olimpijska regija	Paralija	t	16
e43d1223-4ec8-4d27-8662-919d8560ce88	Hrvatska	hrvatska	Zagreb	Zagreb	t	0
007e4c98-9f78-45f4-9528-18d38bb43a7d	Hrvatska	hrvatska	Karlovac	Karlovac	t	1
0dfd4d92-6de6-49c2-8625-e14bc64e22d1	Hrvatska	hrvatska	Rijeka i Opatija	Rijeka	t	2
a4058f33-b434-4604-bea3-519383ae3a02	Hrvatska	hrvatska	Rijeka i Opatija	Opatija	t	3
ffa4dd3c-7e66-44e8-a637-862b580200a0	Hrvatska	hrvatska	Istra	Novigrad	t	4
e308316d-6887-4383-b017-f009ee6f85e3	Hrvatska	hrvatska	Istra	Umag	t	5
e37502eb-1c64-405e-8279-d114068fe411	Hrvatska	hrvatska	Istra	Poreč	t	6
c5ba765a-8cc9-423e-a6f0-0d55aeabe9eb	Hrvatska	hrvatska	Istra	Rovinj	t	7
11b0a304-bc88-4742-9b62-12b48f23f6d8	Hrvatska	hrvatska	Istra	Vrsar	t	8
897ae66a-b331-46d6-baa9-0c7147365c72	Hrvatska	hrvatska	Istra	Pula	t	9
347eec2f-b6ae-4f21-ad85-066293065443	Hrvatska	hrvatska	Istra	Medulin	t	10
2baa8d81-f30d-4c31-bb85-c1b10cd75ea8	Hrvatska	hrvatska	Split i Zadar	Split	t	11
aa4d03a1-e190-4009-b47a-a701b597a716	Hrvatska	hrvatska	Split i Zadar	Zadar	t	12
7a71e5df-c312-4198-95f4-62be7f434b7b	Makedonija	makedonija	Skoplje	Skoplje	t	0
68185c74-767f-4a0f-b9e8-ee943ff7b780	Makedonija	makedonija	Ohrid	Ohrid	t	1
1021e12d-bb70-4092-ad68-c892c7e8d9c4	Italija	italija	Trst	Trst	t	0
63c7a4b8-5d48-42d4-a3d6-b116589a44a2	Slovenija	slovenija	Slovenija	Ljubljana	f	0
140e65b1-3a65-41ce-abaa-f658012b0e8d	Slovenija	slovenija	Slovenija	Maribor	f	1
2441eca6-6309-4add-b596-c94ac9e2c8f8	Slovenija	slovenija	Slovenija	Celje	f	2
e3398aef-ccdd-43d9-850e-e2a095164735	Slovenija	slovenija	Slovenija	Ptuj	f	3
6ddaaca3-838b-40bf-9099-413e99c09e5d	Slovenija	slovenija	Slovenija	Novo Mesto	f	4
0f78da7d-c0b5-4f69-97f7-6ee180c99fcd	Slovenija	slovenija	Slovenija	Brežice	f	5
574d2575-50ff-4699-8ad8-d5518cfc3e02	Slovenija	slovenija	Slovenija	Bled	f	6
a180daef-f479-4e67-82ef-4bf937b92273	Bosna i Hercegovina	bih	Sarajevo	Sarajevo	f	0
d0c235a0-8021-430a-b625-6b04bbdeff35	Bosna i Hercegovina	bih	Jahorina	Jahorina	f	1
429dc0cd-c2a9-4580-98a2-744f9c188a55	Srbija	srbija	Niš	Niš	t	2
\.


--
-- Data for Name: profiles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."profiles" ("id", "ime", "email", "boja") FROM stdin;
22ecbb36-23fd-4d78-905d-fb8f0d2c89ca	Petar	petarsosic4@gmail.com	#d97706
56231ad7-e99a-4425-ae45-f87a82b2c07d	Mihajlo	mihajlo28122002@gmail.com	#2563eb
\.


--
-- Data for Name: reservations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."reservations" ("id", "ime", "telefon", "destinacija_id", "datum_polaska", "destinacija_povratka_id", "datum_povratka", "broj_putnika", "kreirao") FROM stdin;
00000000-0000-4000-8000-100000000001	Marko Petrović	+381641234567	d733552e-8f8f-462b-a326-adc6bbaf7fe8	2026-09-11	de97c014-4065-4e50-9599-f198f979d2cb	2026-09-25	4	56231ad7-e99a-4425-ae45-f87a82b2c07d
00000000-0000-4000-8000-100000000002	Jelena Ilić	+381631112233	8d1e8dc7-720d-4dc0-b74f-fe4330f49f61	2026-08-28	de97c014-4065-4e50-9599-f198f979d2cb	2026-09-04	2	22ecbb36-23fd-4d78-905d-fb8f0d2c89ca
00000000-0000-4000-8000-100000000003	Porodica Jovanović	+381652223344	a15be6b4-e91f-4661-b590-89dc5a370075	2026-08-23	de97c014-4065-4e50-9599-f198f979d2cb	2026-09-06	5	56231ad7-e99a-4425-ae45-f87a82b2c07d
00000000-0000-4000-8000-100000000004	Stefan Nikolić	+381603334455	e43d1223-4ec8-4d27-8662-919d8560ce88	2026-08-25	de97c014-4065-4e50-9599-f198f979d2cb	\N	1	22ecbb36-23fd-4d78-905d-fb8f0d2c89ca
00000000-0000-4000-8000-100000000005	Ana Marković	+381644445566	de97c014-4065-4e50-9599-f198f979d2cb	2026-08-31	de97c014-4065-4e50-9599-f198f979d2cb	\N	3	56231ad7-e99a-4425-ae45-f87a82b2c07d
00000000-0000-4000-8000-100000000006	Dragan Đorđević	+381665556677	c99e0e87-e42d-4d2c-99fb-f010ba5f4bb9	2026-08-30	de97c014-4065-4e50-9599-f198f979d2cb	2026-08-30	21	22ecbb36-23fd-4d78-905d-fb8f0d2c89ca
00000000-0000-4000-8000-100000000007	Šaban Šaulić	+381667778899	63c7a4b8-5d48-42d4-a3d6-b116589a44a2	2026-09-07	de97c014-4065-4e50-9599-f198f979d2cb	2026-09-09	2	56231ad7-e99a-4425-ae45-f87a82b2c07d
00000000-0000-4000-8000-100000000008	Aleksandar Cvetković	+381628889900	d733552e-8f8f-462b-a326-adc6bbaf7fe8	2026-08-30	de97c014-4065-4e50-9599-f198f979d2cb	2026-09-13	6	22ecbb36-23fd-4d78-905d-fb8f0d2c89ca
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."settings" ("id", "podrazumevana_destinacija_id") FROM stdin;
1	de97c014-4065-4e50-9599-f198f979d2cb
\.


--
-- Name: destinacije destinacije_kljuc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."destinacije"
    ADD CONSTRAINT "destinacije_kljuc" UNIQUE ("drzava_sifra", "regija", "grad");


--
-- Name: destinacije destinacije_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."destinacije"
    ADD CONSTRAINT "destinacije_pkey" PRIMARY KEY ("id");


--
-- Name: profiles profiles_email_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."profiles"
    ADD CONSTRAINT "profiles_email_unique" UNIQUE ("email");


--
-- Name: profiles profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."profiles"
    ADD CONSTRAINT "profiles_pkey" PRIMARY KEY ("id");


--
-- Name: reservations reservations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."reservations"
    ADD CONSTRAINT "reservations_pkey" PRIMARY KEY ("id");


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."settings"
    ADD CONSTRAINT "settings_pkey" PRIMARY KEY ("id");


--
-- Name: destinacije_aktivna_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "destinacije_aktivna_idx" ON "public"."destinacije" USING "btree" ("aktivna");


--
-- Name: destinacije_drzava_sifra_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "destinacije_drzava_sifra_idx" ON "public"."destinacije" USING "btree" ("drzava_sifra");


--
-- Name: reservations_datum_polaska_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "reservations_datum_polaska_idx" ON "public"."reservations" USING "btree" ("datum_polaska");


--
-- Name: reservations_datum_povratka_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "reservations_datum_povratka_idx" ON "public"."reservations" USING "btree" ("datum_povratka");


--
-- Name: profiles profiles_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."profiles"
    ADD CONSTRAINT "profiles_id_users_id_fk" FOREIGN KEY ("id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: reservations reservations_destinacija_id_destinacije_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."reservations"
    ADD CONSTRAINT "reservations_destinacija_id_destinacije_id_fk" FOREIGN KEY ("destinacija_id") REFERENCES "public"."destinacije"("id") ON DELETE RESTRICT;


--
-- Name: reservations reservations_destinacija_povratka_id_destinacije_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."reservations"
    ADD CONSTRAINT "reservations_destinacija_povratka_id_destinacije_id_fk" FOREIGN KEY ("destinacija_povratka_id") REFERENCES "public"."destinacije"("id") ON DELETE RESTRICT;


--
-- Name: reservations reservations_kreirao_profiles_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."reservations"
    ADD CONSTRAINT "reservations_kreirao_profiles_id_fk" FOREIGN KEY ("kreirao") REFERENCES "public"."profiles"("id") ON DELETE RESTRICT;


--
-- Name: settings settings_podrazumevana_destinacija_id_destinacije_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."settings"
    ADD CONSTRAINT "settings_podrazumevana_destinacija_id_destinacije_id_fk" FOREIGN KEY ("podrazumevana_destinacija_id") REFERENCES "public"."destinacije"("id") ON DELETE RESTRICT;


--
-- Name: reservations clanovi_delete_reservations; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "clanovi_delete_reservations" ON "public"."reservations" FOR DELETE TO "authenticated" USING ("public"."je_clan"());


--
-- Name: reservations clanovi_insert_reservations; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "clanovi_insert_reservations" ON "public"."reservations" FOR INSERT TO "authenticated" WITH CHECK ("public"."je_clan"());


--
-- Name: destinacije clanovi_select_destinacije; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "clanovi_select_destinacije" ON "public"."destinacije" FOR SELECT TO "authenticated" USING ("public"."je_clan"());


--
-- Name: profiles clanovi_select_profiles; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "clanovi_select_profiles" ON "public"."profiles" FOR SELECT TO "authenticated" USING ("public"."je_clan"());


--
-- Name: reservations clanovi_select_reservations; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "clanovi_select_reservations" ON "public"."reservations" FOR SELECT TO "authenticated" USING ("public"."je_clan"());


--
-- Name: settings clanovi_select_settings; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "clanovi_select_settings" ON "public"."settings" FOR SELECT TO "authenticated" USING ("public"."je_clan"());


--
-- Name: profiles clanovi_update_own_profile; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "clanovi_update_own_profile" ON "public"."profiles" FOR UPDATE TO "authenticated" USING ((( SELECT "auth"."uid"() AS "uid") = "id")) WITH CHECK ((( SELECT "auth"."uid"() AS "uid") = "id"));


--
-- Name: reservations clanovi_update_reservations; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "clanovi_update_reservations" ON "public"."reservations" FOR UPDATE TO "authenticated" USING ("public"."je_clan"()) WITH CHECK ("public"."je_clan"());


--
-- Name: settings clanovi_update_settings; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "clanovi_update_settings" ON "public"."settings" FOR UPDATE TO "authenticated" USING ("public"."je_clan"()) WITH CHECK ("public"."je_clan"());


--
-- Name: destinacije; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."destinacije" ENABLE ROW LEVEL SECURITY;

--
-- Name: profiles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."profiles" ENABLE ROW LEVEL SECURITY;

--
-- Name: reservations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."reservations" ENABLE ROW LEVEL SECURITY;

--
-- Name: settings; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."settings" ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--

\unrestrict DW6rUsZGdCTTKA5YoQcubCwy4xUJyRgdVTitmA9RueLa440X8hvghQhHwfciyWw

